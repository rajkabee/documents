/**
 * AspectJ-based scheduling support.
 */
@NonNullApi
@NonNullFields
package org.springframework.scheduling.aspectj;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
