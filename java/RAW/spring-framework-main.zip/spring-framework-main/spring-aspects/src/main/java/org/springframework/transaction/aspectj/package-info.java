/**
 * AspectJ-based transaction management support.
 */
@NonNullApi
@NonNullFields
package org.springframework.transaction.aspectj;

import org.springframework.lang.NonNullApi;
import org.springframework.lang.NonNullFields;
